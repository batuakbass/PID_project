% =========================================================================
% MATH1002 Calculus II - PID Control Testbench
% Authors : O. A. Sevim, B. Akbas, C. A. Ceylan, V. K. Bulut, H. Kilinc
% Date    : May 2026
%
% Plant: unit-mass body, m*x'' = u  ->  P(s) = 1/s^2 (double integrator).
% The script runs the two lab scenarios (step reference at t = 2 s and a
% 5 N wind disturbance at t = 6 s), compares P, PD and PID controllers,
% computes the four required metrics (overshoot, settling time, IAE,
% steady-state error) and draws Figures 1-6 used in the report.
% =========================================================================

clear; clc; close all;

%% ===== System parameters =====
m  = 1.0;            % mass [kg]
dt = 0.001;          % integration step (Euler) [s]
T  = 0:dt:15;        % simulation time vector [s]
N  = length(T);

%% ===== Reference signal (Scenario A) =====
% Position command steps from 0 to 10 m at t = 2 s.
xref = zeros(1, N);
xref(T >= 2) = 10;

%% ===== Disturbance signal (Scenario B) =====
% Constant 5 N wind force switched on at t = 6 s (within the 3-10 N range
% suggested by the handout).
d = zeros(1, N);
d(T >= 6) = 5;

%% ===== Controller gains =====
% Tuned in three stages: Kp sets the natural frequency, Kd adds damping,
% Ki removes the steady-state error left by the wind.
Kp_P  = 4.0;  Ki_P  = 0.0;  Kd_P  = 0.0;   % P  controller
Kp_PD = 4.0;  Ki_PD = 0.0;  Kd_PD = 3.0;   % PD controller
Kp_PID= 4.0;  Ki_PID= 1.0;  Kd_PID= 3.0;   % PID controller
uLim  = 25;                                % actuator saturation [N]

%% ===== Run the simulations =====
% Each controller is run twice: once with the wind (Scenario B) and once
% without it (Scenario A) so the step response can be measured cleanly.
[X_P  , E_P  , U_P  ] = run_pid(T, xref, d, m, Kp_P  , Ki_P  , Kd_P  , uLim);
[X_PD , E_PD , U_PD ] = run_pid(T, xref, d, m, Kp_PD , Ki_PD , Kd_PD , uLim);
[X_PID, E_PID, U_PID] = run_pid(T, xref, d, m, Kp_PID, Ki_PID, Kd_PID, uLim);

dZero = zeros(1, N);                        % no-disturbance case
X_P0   = run_pid(T, xref, dZero, m, Kp_P  , Ki_P  , Kd_P  , uLim);
X_PD0  = run_pid(T, xref, dZero, m, Kp_PD , Ki_PD , Kd_PD , uLim);
X_PID0 = run_pid(T, xref, dZero, m, Kp_PID, Ki_PID, Kd_PID, uLim);

%% ===== Performance metrics =====
idx2  = find(T >= 2 , 1);
idx6  = find(T >= 6 , 1);
idx10 = find(T >= 10, 1);

% Overshoot is measured on the clean step (before the wind hits).
OS_P   = max(0, (max(X_P0  (idx2:idx6)) - 10) / 10 * 100);
OS_PD  = max(0, (max(X_PD0 (idx2:idx6)) - 10) / 10 * 100);
OS_PID = max(0, (max(X_PID0(idx2:idx6)) - 10) / 10 * 100);

% Integral of the absolute error over the full run (with the wind).
IAE_P   = trapz(T, abs(E_P));
IAE_PD  = trapz(T, abs(E_PD));
IAE_PID = trapz(T, abs(E_PID));

% Steady-state error: average error during the last seconds of the run.
ess_P   = mean(E_P  (idx10:end));
ess_PD  = mean(E_PD (idx10:end));
ess_PID = mean(E_PID(idx10:end));

% PD settling time on the clean step, 2 % band around 10 m.
band   = 0.02 * 10;
seg    = idx2:idx6;
out    = find(abs(X_PD0(seg) - 10) > band);
if isempty(out)
    Ts_PD = 0;
else
    Ts_PD = T(idx2 + out(end) - 1) - 2;
end

%% ===== Print the results =====
fprintf('\n========== PID CONTROL TESTBENCH RESULTS ==========\n');
fprintf('Overshoot   : P = %5.2f %%   PD = %4.2f %%   PID = %5.2f %%\n', ...
        OS_P, OS_PD, OS_PID);
fprintf('IAE [m*s]   : P = %5.1f     PD = %4.1f     PID = %4.1f\n', ...
        IAE_P, IAE_PD, IAE_PID);
fprintf('ess (wind)  : P = %5.2f m   PD = %5.2f m   PID = %5.2f m\n', ...
        ess_P, ess_PD, ess_PID);
fprintf('PD settling time (step) : %.2f s\n', Ts_PD);
fprintf('===================================================\n');

%% ===== Plot colours and dark style =====
cRef = [0.85 0.85 0.85];
cP   = [0.90 0.15 0.15];
cPD  = [0.15 0.75 0.20];
cPID = [0.20 0.40 0.95];

%% ===== Figure 1: Step response, no disturbance =====
f1 = figure('Name', 'Step Response Comparison (No Disturbance)');
plot(T, xref  , '--', 'Color', cRef, 'LineWidth', 2); hold on;
plot(T, X_P0  , 'Color', cP , 'LineWidth', 2);
plot(T, X_PD0 , 'Color', cPD, 'LineWidth', 2);
plot(T, X_PID0, 'Color', cPID,'LineWidth', 2);
xlabel('Time (seconds)'); ylabel('Position Response');
title('Figure 1: Step Response Comparison (No Disturbance)');
legend('Reference','P Control','PD Control','PID Control','Location','northeast');
ylim([0 25]);
text(4.4, 11.7, sprintf('PID: OS=%.2f%%', OS_PID), 'Color', cPID);
text(4.4, 11.0, sprintf('PD: OS=%.2f%%' , OS_PD ), 'Color', cPD);
text(4.4, 10.4, sprintf('Ts=%.2fs'      , Ts_PD ), 'Color', cPD);
styleDark(gca, f1);

%% ===== Figure 2: Disturbance response (Scenario B) =====
f2 = figure('Name', 'Disturbance Response (Scenario B)');
plot(T, xref , '--', 'Color', cRef, 'LineWidth', 2); hold on;
plot(T, X_P  , 'Color', cP , 'LineWidth', 2);
plot(T, X_PD , 'Color', cPD, 'LineWidth', 2);
plot(T, X_PID, 'Color', cPID,'LineWidth', 2);
xline(6, '--m', 'Disturbance ON (5N at t=6s)', 'Color', 'm', ...
      'LabelVerticalAlignment', 'top');
xlabel('Time (seconds)'); ylabel('Position Response');
title('Figure 2: Disturbance Response (Scenario B - All Controllers)');
legend('Reference','P Control','PD Control','PID Control','Location','northeast');
ylim([0 25]);
text(11, 11, 'PID: recovers to ess~0 (integral action)', 'Color', cPID);
text(0.3, 8.7, 'PD: ess = -1.25m (permanent offset)'   , 'Color', cPD);
styleDark(gca, f2);

%% ===== Figure 3: Error signals (Scenario B) =====
f3 = figure('Name', 'Error Signal Comparison (Scenario B)');
plot(T, E_P  , 'Color', cP , 'LineWidth', 2); hold on;
plot(T, E_PD , 'Color', cPD, 'LineWidth', 2);
plot(T, E_PID, 'Color', cPID,'LineWidth', 2);
yline(0, '--', 'Color', cRef);
xline(6, '--m', 'Disturbance ON', 'Color', 'm');
xlabel('Time (seconds)'); ylabel('Error e(t) [m]');
title('Figure 3: Error Signal Comparison (Scenario B)');
legend('P Error','PD Error','PID Error','Location','northeast');
ylim([-5 15]);
styleDark(gca, f3);

%% ===== Figure 4: Control input signals with anti-windup =====
f4 = figure('Name', 'Control Input Signals (Anti-Windup at +/-25N)');
sgt = sgtitle('Figure 4: Control Input Signals (Anti-Windup at \pm25N)');
set(sgt, 'Color', 'w');

ax1 = subplot(3,1,1);
plot(T, U_P, 'Color', cP, 'LineWidth', 1.5); hold on;
yline( uLim, '--y'); yline(-uLim, '--y'); xline(6, '--m');
ylabel('u(t) [N]'); legend('P Control Input u(t)','Location','northeast');
styleDark(ax1, f4);

ax2 = subplot(3,1,2);
plot(T, U_PD, 'Color', cPD, 'LineWidth', 1.5); hold on;
yline( uLim, '--y'); yline(-uLim, '--y'); xline(6, '--m');
ylabel('u(t) [N]'); legend('PD Control Input u(t)','Location','northeast');
styleDark(ax2, f4);

ax3 = subplot(3,1,3);
plot(T, U_PID, 'Color', cPID, 'LineWidth', 1.5); hold on;
yline( uLim, '--y'); yline(-uLim, '--y'); xline(6, '--m');
yline(-5, ':c'); text(8, -4, 'Steady-state u = -5N (counteracts +5N wind)', 'Color', 'c');
xlabel('Time (seconds)'); ylabel('u(t) [N]');
legend('PID Control Input u(t)','Location','northeast');
styleDark(ax3, f4);

%% ===== Figure 5: Performance metrics summary =====
f5 = figure('Name', 'Performance Metrics Summary');
sgt = sgtitle('Figure 5: Performance Metrics Summary');
set(sgt, 'Color', 'w');
labels = {'P','PD','PID'};

ax1 = subplot(1,3,1);
b = bar([OS_P OS_PD OS_PID]); b.FaceColor = 'flat';
b.CData = [cP; cPD; cPID];
set(gca,'XTickLabel',labels); ylabel('Overshoot (%)'); title('Overshoot');
text(1, OS_P  , sprintf('%.0f%%'  , OS_P  ), 'HorizontalAlignment','center','VerticalAlignment','bottom','Color','w');
text(2, OS_PD , sprintf('%.1f%%'  , OS_PD ), 'HorizontalAlignment','center','VerticalAlignment','bottom','Color','w');
text(3, OS_PID, sprintf('%.2f%%'  , OS_PID), 'HorizontalAlignment','center','VerticalAlignment','bottom','Color','w');
styleDark(ax1, f5);

ax2 = subplot(1,3,2);
b = bar([IAE_P IAE_PD IAE_PID]); b.FaceColor = 'flat';
b.CData = [cP; cPD; cPID];
set(gca,'XTickLabel',labels); ylabel('IAE (m*s)'); title('Integral Absolute Error');
text(1, IAE_P  , sprintf('%.1f', IAE_P  ), 'HorizontalAlignment','center','VerticalAlignment','bottom','Color','w');
text(2, IAE_PD , sprintf('%.1f', IAE_PD ), 'HorizontalAlignment','center','VerticalAlignment','bottom','Color','w');
text(3, IAE_PID, sprintf('%.1f', IAE_PID), 'HorizontalAlignment','center','VerticalAlignment','bottom','Color','w');
styleDark(ax2, f5);

ax3 = subplot(1,3,3);
% P oscillates, so its disturbance ess is not meaningful; plot PD and PID.
b = bar([0 ess_PD ess_PID]); b.FaceColor = 'flat';
b.CData = [cP; cPD; cPID];
set(gca,'XTickLabel',labels); ylabel('ess with dist. (m)'); title('Steady-State Error');
text(3, ess_PID, sprintf('%.2fm', ess_PID), 'HorizontalAlignment','center','VerticalAlignment','top','Color','w');
text(2, ess_PD , sprintf('%.2fm', ess_PD ), 'HorizontalAlignment','center','VerticalAlignment','top','Color','w');
styleDark(ax3, f5);

%% ===== Figure 6: Closed-loop pole locations in the s-plane =====
% Characteristic polynomials of the unity-feedback loop with P = 1/s^2:
%   P  : s^2 + Kp = 0
%   PD : s^2 + Kd*s + Kp = 0
%   PID: s^3 + Kd*s^2 + Kp*s + Ki = 0
poles_P   = roots([1 0 Kp_P]);
poles_PD  = roots([1 Kd_PD Kp_PD]);
poles_PID = roots([1 Kd_PID Kp_PID Ki_PID]);

f6 = figure('Name', 'Closed-Loop Pole Locations in S-Plane');
sgt = sgtitle('Figure 6: Closed-Loop Pole Locations in S-Plane');
set(sgt, 'Color', 'w');

ax1 = subplot(1,3,1);
plotPoles(poles_P, cP); title({'P Controller','Marginally Stable (\zeta=0)'});
styleDark(ax1, f6);

ax2 = subplot(1,3,2);
plotPoles(poles_PD, cPD); title({'PD Controller','Underdamped (\zeta=0.75)'});
styleDark(ax2, f6);

ax3 = subplot(1,3,3);
plotPoles(poles_PID, cPID); title({'PID Controller','Stable (3rd Order)'});
styleDark(ax3, f6);

% =========================================================================
% Local functions
% =========================================================================

function [X, E, U] = run_pid(T, xref, d, m, Kp, Ki, Kd, uLim)
% RUN_PID  Discrete-time PID loop with Euler integration and anti-windup.
%   Returns position X, error E and (saturated) control U over time T.
%   The integrator is rolled back whenever the actuator saturates
%   (back-calculation) so it cannot wind up during large transients.
    N = length(T);  dt = T(2) - T(1);
    X = zeros(1, N);  E = zeros(1, N);  U = zeros(1, N);
    x = 0;  v = 0;  integ = 0;  prev_e = 0;

    for i = 1:N
        e     = xref(i) - x;                 % tracking error
        integ = integ + e * dt;              % integral term
        deriv = (e - prev_e) / dt;           % derivative term
        prev_e = e;

        u_raw = Kp*e + Ki*integ + Kd*deriv;  % unsaturated PID output
        u_sat = max(-uLim, min(uLim, u_raw));% actuator saturation

        % Anti-windup: undo the last integration step while saturated.
        if u_raw ~= u_sat && sign(e) == sign(u_raw)
            integ = integ - e * dt;
        end

        a = (u_sat + d(i)) / m;              % Newton's second law
        v = v + a * dt;                      % velocity update
        x = x + v * dt;                      % position update

        X(i) = x;  E(i) = e;  U(i) = u_sat;
    end
end

function plotPoles(p, c)
% PLOTPOLES  Draw closed-loop poles on the s-plane with the stable (LHP)
%   region shaded and each pole labelled by its value.
    fill([-3 0 0 -3], [-3 -3 3 3], [0.0 0.15 0.0], 'EdgeColor', 'none'); hold on;
    plot([0 0], [-3 3], 'w-'); plot([-3 3], [0 0], 'w-');
    plot(real(p), imag(p), 'o', 'MarkerFaceColor', c, 'MarkerEdgeColor', c, ...
         'MarkerSize', 11);
    for k = 1:numel(p)
        if abs(imag(p(k))) < 1e-6
            lbl = sprintf('%.2f', real(p(k)));
        else
            lbl = sprintf('%.2f%+.2fj', real(p(k)), imag(p(k)));
        end
        text(real(p(k))+0.1, imag(p(k))+0.25, lbl, 'Color', c, 'FontSize', 8);
    end
    text(-2.8, 2.7, 'Stable (LHP)', 'Color', [0.4 0.8 0.4], 'FontSize', 8);
    text( 1.0, 2.7, 'Unstable'    , 'Color', [0.8 0.4 0.4], 'FontSize', 8);
    xlabel('Real Axis'); ylabel('Imaginary Axis');
    xlim([-3 3]); ylim([-3 3]); axis square;
end

function styleDark(ax, fig)
% STYLEDARK  Apply the dark report theme to one axes/figure.
    set(fig, 'Color', [0.13 0.13 0.13]);
    set(ax , 'Color', [0.13 0.13 0.13], 'XColor', 'w', 'YColor', 'w', ...
             'GridColor', [0.6 0.6 0.6], 'GridAlpha', 0.35);
    grid(ax, 'on');
    set(get(ax, 'Title') , 'Color', 'w');
    set(get(ax, 'XLabel'), 'Color', 'w');
    set(get(ax, 'YLabel'), 'Color', 'w');
end
